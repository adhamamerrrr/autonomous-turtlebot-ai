Place the trained smoke detection checkpoint at integration_bridge/best.pt. Do not commit service-account JSON keys. Configure Firebase through environment or local secure credentials.
